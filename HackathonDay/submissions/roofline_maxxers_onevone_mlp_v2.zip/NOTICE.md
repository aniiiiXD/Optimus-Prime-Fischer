# Roofline Maxxers OneVOne

Official entry point: agent.py. Runtime dependencies: Python 3.11, NumPy, and the official pinned catanatron engine. No PyTorch is imported during play.

Source: https://github.com/aniiiiXD/Optimus-Prime-Fischer
Source commit before packaging: 16e8259500b9f2d4b850ccbf380e9c2ba5b0a1cf

Uses catanatron by Bryan Collazo (GPL-3.0-or-later), installed by the official kit: https://github.com/bcollazo/catanatron
Official interface and engine: https://github.com/lyric-hyde/catan-hackathon-agent

The heuristic is derived from this team's pre-event OneVOne experiments. This package does not certify compliance with the event's built-during-event rule; organizers determine eligibility. The neural redesign and outcome checkpoints were created during the current development session.
